package com.valtech.training.corejava.d4;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BoxingTest {

	@Test
	void test() {
		Integer i =new Integer(5);
		Integer j=5; //
		int k = j.intValue();
		int l = j;
	}

}
