package com.valtech.training.corejava.d2;

public class StringTest {

}
