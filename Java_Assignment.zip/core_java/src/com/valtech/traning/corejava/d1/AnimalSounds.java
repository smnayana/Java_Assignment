package com.valtech.traning.corejava.d1;

public class AnimalSounds {
	public void disturb() {
		System.out.println("hello");
}
}
