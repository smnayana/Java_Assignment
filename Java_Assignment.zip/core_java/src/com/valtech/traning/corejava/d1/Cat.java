package com.valtech.traning.corejava.d1;

public class Cat implements Animal {

	@Override
	public void makeSound() {
		System.out.println("meow.......");
	}

}
