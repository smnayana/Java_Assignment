package com.valtech.traning.corejava.d1;

public class electricvehicle extends Vehicle {

	@Override
	public void accelerate() {
		System.out.println("cut off power........");
	}

	@Override
	public void applyBreak() {
		System.out.println("applied break..........");
		
		
	}

}
