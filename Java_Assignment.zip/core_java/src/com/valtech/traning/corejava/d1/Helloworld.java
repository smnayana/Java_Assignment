package com.valtech.traning.corejava.d1;

public class Helloworld {
	public static void main(String[] args) {
	System.out.println("Hello world");
		
	}
	
}
