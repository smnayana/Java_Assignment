package com.valtech.traning.corejava.d1;

public interface Animal {
	
	int NUM_OF_LEGS =4;
	
	void makeSound( );

	

}
